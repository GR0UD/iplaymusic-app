import "../globals.css";

export default function PlainLayout({ children }) {
  return <>{children}</>;
}
