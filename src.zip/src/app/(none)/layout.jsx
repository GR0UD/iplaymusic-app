"use client";

export default function PlainLayout({ children }) {
  return <>{children}</>;
}
